﻿'*****************************************************************
' Team Number: 12
' Team Member 1 Details: Sedu, MSAS (220042255)
' Team Member 2 Details: Pathan, MP (220012601)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: frmCD
' *****************************************************************

Option Strict On
Option Infer Off
Option Explicit On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmCD
    'Object Array
    Private Disease() As Disease
    'File
    Private fls As FileStream
    Private bnf As BinaryFormatter

    Private Sub frmCD_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ReDim Disease(3)
    End Sub

    'TB
    'Details
    Private Sub BtnTBDetails_Click(sender As Object, e As EventArgs) Handles BtnTBDetails.Click
        Dim tb As TB
        Dim months As Integer = CInt(InputBox("How many months is the disease being monitored for?", "Months"))
        Dim medMonths As Integer = CInt(InputBox("How many many months has the mediacation been prescribed for?", "Medication"))
        tb = New TB(months, medMonths)
        For i As Integer = 1 To months
            tb.Cases(i) = CInt(InputBox("How many cases were recorded in the month " & CStr(i), "Cases?"))
        Next i
        tb.Deaths = CInt(InputBox("how many people died of TB?", "Deaths?"))
        Disease(3) = tb
    End Sub
    'File
    Private Sub BtnTBFile_Click(sender As Object, e As EventArgs) Handles BtnTBFile.Click
        fls = New FileStream("TBFile.ifm", FileMode.Create, FileAccess.Write)
        bnf = New BinaryFormatter
        bnf.Serialize(fls, Disease(3))
        TxtTBDisplay.Text = "File Has Been Saved Successfully!"
        fls.Close()
        bnf = Nothing
        fls = Nothing
    End Sub
    'Display
    Private Sub BtnTBDisplay_Click(sender As Object, e As EventArgs) Handles BtnTBDisplay.Click
        fls = New FileStream("TB.ifm", FileMode.Open, FileAccess.Read)
        bnf = New BinaryFormatter
        Dim tbTemp As TB
        tbTemp = DirectCast(bnf.Deserialize(fls), TB)
        TxtTBDisplay.Text = tbTemp.Display()
        fls.Close()
        bnf = Nothing
        fls = Nothing
    End Sub

    'Malaria
    'Details
    Private Sub BtnMDetails_Click(sender As Object, e As EventArgs) Handles BtnMDetails.Click
        Dim Malaria As Malaria
        Dim Months, Mosquito, Nets As Integer
        Dim Area, Water As Double
        'Get Values
        Months = CInt(InputBox("How many Months?"))
        Mosquito = CInt(InputBox("How many Mosquitos per Square KM (Integer)?"))
        Nets = CInt(InputBox("How many Nets in Houses per Square KM (Integer)?"))
        Area = CDbl(InputBox("What is the Area of the Location?"))
        Water = CDbl(InputBox("What is the Estimated Water Levels in the Location ?"))
        'Instantiate
        Malaria = New Malaria(Months, Mosquito, Area, Water, Nets)
        'Get Number of Cases
        Dim a As Integer
        For a = 1 To Months
            Malaria.Cases(a) = CInt(InputBox("How many Cases occured in Month " & a & "?"))
        Next a
        Malaria.Deaths = CInt(InputBox("How many People have died due to Malaria?"))
        Disease(2) = Malaria
    End Sub
    'File
    Private Sub BtnMFile_Click(sender As Object, e As EventArgs) Handles BtnMFile.Click
        fls = New FileStream("Malaria.ifm", FileMode.Create, FileAccess.Write)
        bnf = New BinaryFormatter
        bnf.Serialize(fls, Disease(2))
        TxtMDisplay.Text = "File Has Been Saved Successfully!"
        fls.Close()
        bnf = Nothing
        fls = Nothing
    End Sub
    'Display 
    Private Sub BtnMDisplay_Click(sender As Object, e As EventArgs) Handles BtnMDisplay.Click
        fls = New FileStream("Malaria.ifm", FileMode.Open, FileAccess.Read)
        bnf = New BinaryFormatter
        Dim tbTemp As Malaria
        tbTemp = DirectCast(bnf.Deserialize(fls), Malaria)
        TxtMDisplay.Text = tbTemp.Display()
        fls.Close()
    End Sub
End Class
