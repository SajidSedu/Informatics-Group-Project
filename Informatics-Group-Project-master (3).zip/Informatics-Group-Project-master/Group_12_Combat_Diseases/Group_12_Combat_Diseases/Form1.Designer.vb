﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCD
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblHIV = New System.Windows.Forms.Label()
        Me.lblTB = New System.Windows.Forms.Label()
        Me.lblMalaria = New System.Windows.Forms.Label()
        Me.BtnTBDetails = New System.Windows.Forms.Button()
        Me.BtnTBDisplay = New System.Windows.Forms.Button()
        Me.TxtTBDisplay = New System.Windows.Forms.TextBox()
        Me.BtnTBFile = New System.Windows.Forms.Button()
        Me.BtnMDetails = New System.Windows.Forms.Button()
        Me.BtnMFile = New System.Windows.Forms.Button()
        Me.BtnMDisplay = New System.Windows.Forms.Button()
        Me.TxtMDisplay = New System.Windows.Forms.TextBox()
        Me.TxtHIVDisplay = New System.Windows.Forms.TextBox()
        Me.BtnHIVDisplay = New System.Windows.Forms.Button()
        Me.BtnHIVFile = New System.Windows.Forms.Button()
        Me.BtnHIVDetails = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LblHIV
        '
        Me.LblHIV.AutoSize = True
        Me.LblHIV.Location = New System.Drawing.Point(92, 17)
        Me.LblHIV.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblHIV.Name = "LblHIV"
        Me.LblHIV.Size = New System.Drawing.Size(25, 13)
        Me.LblHIV.TabIndex = 0
        Me.LblHIV.Text = "HIV"
        '
        'lblTB
        '
        Me.lblTB.AutoSize = True
        Me.lblTB.Location = New System.Drawing.Point(592, 17)
        Me.lblTB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTB.Name = "lblTB"
        Me.lblTB.Size = New System.Drawing.Size(21, 13)
        Me.lblTB.TabIndex = 1
        Me.lblTB.Text = "TB"
        '
        'lblMalaria
        '
        Me.lblMalaria.AutoSize = True
        Me.lblMalaria.Location = New System.Drawing.Point(328, 17)
        Me.lblMalaria.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMalaria.Name = "lblMalaria"
        Me.lblMalaria.Size = New System.Drawing.Size(41, 13)
        Me.lblMalaria.TabIndex = 2
        Me.lblMalaria.Text = "Malaria"
        '
        'BtnTBDetails
        '
        Me.BtnTBDetails.Location = New System.Drawing.Point(538, 44)
        Me.BtnTBDetails.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnTBDetails.Name = "BtnTBDetails"
        Me.BtnTBDetails.Size = New System.Drawing.Size(127, 25)
        Me.BtnTBDetails.TabIndex = 3
        Me.BtnTBDetails.Text = "Enter details"
        Me.BtnTBDetails.UseVisualStyleBackColor = True
        '
        'BtnTBDisplay
        '
        Me.BtnTBDisplay.Location = New System.Drawing.Point(538, 127)
        Me.BtnTBDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnTBDisplay.Name = "BtnTBDisplay"
        Me.BtnTBDisplay.Size = New System.Drawing.Size(127, 25)
        Me.BtnTBDisplay.TabIndex = 4
        Me.BtnTBDisplay.Text = "Display info"
        Me.BtnTBDisplay.UseVisualStyleBackColor = True
        '
        'TxtTBDisplay
        '
        Me.TxtTBDisplay.Location = New System.Drawing.Point(479, 169)
        Me.TxtTBDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtTBDisplay.Multiline = True
        Me.TxtTBDisplay.Name = "TxtTBDisplay"
        Me.TxtTBDisplay.Size = New System.Drawing.Size(233, 186)
        Me.TxtTBDisplay.TabIndex = 5
        '
        'BtnTBFile
        '
        Me.BtnTBFile.Location = New System.Drawing.Point(538, 84)
        Me.BtnTBFile.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnTBFile.Name = "BtnTBFile"
        Me.BtnTBFile.Size = New System.Drawing.Size(127, 25)
        Me.BtnTBFile.TabIndex = 6
        Me.BtnTBFile.Text = "Create file"
        Me.BtnTBFile.UseVisualStyleBackColor = True
        '
        'BtnMDetails
        '
        Me.BtnMDetails.Location = New System.Drawing.Point(286, 44)
        Me.BtnMDetails.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnMDetails.Name = "BtnMDetails"
        Me.BtnMDetails.Size = New System.Drawing.Size(127, 25)
        Me.BtnMDetails.TabIndex = 7
        Me.BtnMDetails.Text = "Enter details"
        Me.BtnMDetails.UseVisualStyleBackColor = True
        '
        'BtnMFile
        '
        Me.BtnMFile.Location = New System.Drawing.Point(286, 84)
        Me.BtnMFile.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnMFile.Name = "BtnMFile"
        Me.BtnMFile.Size = New System.Drawing.Size(127, 25)
        Me.BtnMFile.TabIndex = 8
        Me.BtnMFile.Text = "Create File"
        Me.BtnMFile.UseVisualStyleBackColor = True
        '
        'BtnMDisplay
        '
        Me.BtnMDisplay.Location = New System.Drawing.Point(286, 127)
        Me.BtnMDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnMDisplay.Name = "BtnMDisplay"
        Me.BtnMDisplay.Size = New System.Drawing.Size(127, 25)
        Me.BtnMDisplay.TabIndex = 9
        Me.BtnMDisplay.Text = "Display Info"
        Me.BtnMDisplay.UseVisualStyleBackColor = True
        '
        'TxtMDisplay
        '
        Me.TxtMDisplay.Location = New System.Drawing.Point(245, 169)
        Me.TxtMDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtMDisplay.Multiline = True
        Me.TxtMDisplay.Name = "TxtMDisplay"
        Me.TxtMDisplay.Size = New System.Drawing.Size(230, 186)
        Me.TxtMDisplay.TabIndex = 10
        '
        'TxtHIVDisplay
        '
        Me.TxtHIVDisplay.Location = New System.Drawing.Point(11, 169)
        Me.TxtHIVDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtHIVDisplay.Multiline = True
        Me.TxtHIVDisplay.Name = "TxtHIVDisplay"
        Me.TxtHIVDisplay.Size = New System.Drawing.Size(230, 186)
        Me.TxtHIVDisplay.TabIndex = 14
        '
        'BtnHIVDisplay
        '
        Me.BtnHIVDisplay.Location = New System.Drawing.Point(45, 127)
        Me.BtnHIVDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnHIVDisplay.Name = "BtnHIVDisplay"
        Me.BtnHIVDisplay.Size = New System.Drawing.Size(127, 25)
        Me.BtnHIVDisplay.TabIndex = 13
        Me.BtnHIVDisplay.Text = "STILL TO CODE"
        Me.BtnHIVDisplay.UseVisualStyleBackColor = True
        '
        'BtnHIVFile
        '
        Me.BtnHIVFile.Location = New System.Drawing.Point(45, 84)
        Me.BtnHIVFile.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnHIVFile.Name = "BtnHIVFile"
        Me.BtnHIVFile.Size = New System.Drawing.Size(127, 25)
        Me.BtnHIVFile.TabIndex = 12
        Me.BtnHIVFile.Text = "STILL TO CODE"
        Me.BtnHIVFile.UseVisualStyleBackColor = True
        '
        'BtnHIVDetails
        '
        Me.BtnHIVDetails.Location = New System.Drawing.Point(45, 44)
        Me.BtnHIVDetails.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnHIVDetails.Name = "BtnHIVDetails"
        Me.BtnHIVDetails.Size = New System.Drawing.Size(127, 25)
        Me.BtnHIVDetails.TabIndex = 11
        Me.BtnHIVDetails.Text = "STILL TO CODE"
        Me.BtnHIVDetails.UseVisualStyleBackColor = True
        '
        'frmCD
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(721, 366)
        Me.Controls.Add(Me.TxtHIVDisplay)
        Me.Controls.Add(Me.BtnHIVDisplay)
        Me.Controls.Add(Me.BtnHIVFile)
        Me.Controls.Add(Me.BtnHIVDetails)
        Me.Controls.Add(Me.TxtMDisplay)
        Me.Controls.Add(Me.BtnMDisplay)
        Me.Controls.Add(Me.BtnMFile)
        Me.Controls.Add(Me.BtnMDetails)
        Me.Controls.Add(Me.BtnTBFile)
        Me.Controls.Add(Me.TxtTBDisplay)
        Me.Controls.Add(Me.BtnTBDisplay)
        Me.Controls.Add(Me.BtnTBDetails)
        Me.Controls.Add(Me.lblMalaria)
        Me.Controls.Add(Me.lblTB)
        Me.Controls.Add(Me.LblHIV)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmCD"
        Me.Text = "Combat Diseases"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblHIV As Label
    Friend WithEvents lblTB As Label
    Friend WithEvents lblMalaria As Label
    Friend WithEvents BtnTBDetails As Button
    Friend WithEvents BtnTBDisplay As Button
    Friend WithEvents TxtTBDisplay As TextBox
    Friend WithEvents BtnTBFile As Button
    Friend WithEvents BtnMDetails As Button
    Friend WithEvents BtnMFile As Button
    Friend WithEvents BtnMDisplay As Button
    Friend WithEvents TxtMDisplay As TextBox
    Friend WithEvents TxtHIVDisplay As TextBox
    Friend WithEvents BtnHIVDisplay As Button
    Friend WithEvents BtnHIVFile As Button
    Friend WithEvents BtnHIVDetails As Button
End Class
