﻿'*****************************************************************
' Team Number: 12
' Team Member 1 Details: Sedu, MSAS (220042255)
' Team Member 2 Details: Pathan, MP (220012601)
' Team Member 3 Details: Surname, Initials (Student #)
' Team Member 4 Details: e.g. Smith, J (202000001)
' Practical: Team Project
' Class name: Disease
' *****************************************************************

Public Interface DiseaseCases
    'Gives the Threat Level in that particular region
    Function ThreatLevel() As String
    'Gives the Symptoms of the Disease
    Function Symptoms() As String
End Interface
